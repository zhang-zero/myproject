
import sys


class Message(object):

    def __init__(self, claimedRoot: int, distanceToRoot: int, originID: int, destinationID: int, pathThrough: bool, ttl: int):
        """
        root: int
            the ID of the switch thought to be the root by the origin switch
        distance: int
            the distance of the origin to the root
        origin: int
            the ID of the origin switch (sender)
        destination: int
            the ID of the destination switch (receiver)
        pathThrough: bool
            indicating the path to the claimed root from the origin passes through the destination
        ttl: int
            the time to live remaining on this message
        """
        self.root = claimedRoot
        self.distance = distanceToRoot
        self.origin = originID
        self.destination = destinationID
        self.pathThrough = pathThrough
        self.ttl = ttl

    def verify_message(self):
        """
        Member function that returns True if the message is properly formed, and False otherwise
        """
        valid = True

        if self.pathThrough != True and self.pathThrough != False:
            valid = False
        if isinstance(self.root, int) is False or isinstance(self.distance, int) is False or \
                isinstance(self.origin, int) is False or isinstance(self.destination, int) is False or \
                    isinstance(self.ttl, int) is False:
            valid = False

        return valid

    def __str__(self):
        return (f"""Message<root: {self.root}, distance: {self.distance}, origin: {self.origin}, destination: {self.destination}, pathThrough: {self.pathThrough}, ttl: {self.ttl}>""")


class StpSwitch(object):

    def __init__(self, idNum: int, topolink: object, neighbors: list):
        """
        switchID: int
            the ID of the switch (lowest value determines root and breaks ties)
        topology: Topology object
            a backlink to the Topology class.
            Used for sending messages: self.topology.send_message(message)
        links: list
            the list of switch IDs connected to this switch object
        """
        self.switchID = idNum
        self.topology = topolink
        self.links = neighbors

    # Invoked at initialization of topology of switches, this does NOT need to be invoked by student code.
    def verify_neighbors(self):
        """ Verify that all your neighbors have a backlink to you. """
        for neighbor in self.links:
            if self.switchID not in self.topology.switches[neighbor].links:
                raise Exception(f"{str(neighbor)} does not have link to {str(self.switchID)}")

    # Invoked at initialization of topology of switches, this does NOT need to be invoked by student code.
    def send_initial_messages(self):
        """ Sends all the initial messages.
                Called in Topology.run_spanning_tree()
        """
        for destinationID in self.links:
            self.send_message(
                Message(self.switchID, 0, self.switchID, destinationID, False, self.topology.ttl_limit)
            )

    # Wrapper for message passing to allow students from avoid using self.topology directly
    def send_message(self, message: Message):
        self.topology.send_message(message)

    def __str__(self):
        return (f"""Switch<switchID: {self.switchID}, links: {self.links}>""")



class Switch(StpSwitch):
    def __init__(self, idNum: int, topolink: object, neighbors: list):
        super(Switch, self).__init__(idNum, topolink, neighbors)
        self.root_id = self.switchID
        self.distance_to_root = 0
        self.active_links = []
        self.parent_switch = None

    def process_message(self, message: Message):
        if message.verify_message():
            # 检查是否需要更新根ID和到根的距离
            should_update = message.root < self.root_id or (message.root == self.root_id and message.distance + 1 < self.distance_to_root)

            if should_update:
                self.root_id = message.root
                self.distance_to_root = message.distance + 1
                self.parent_switch = message.origin
                self.active_links = [message.origin]

                # 向除了父交换机以外的所有邻居发送更新的消息
                for neighbor in self.links:
                    if neighbor != self.parent_switch:
                        self.send_message(Message(self.root_id, self.distance_to_root, self.switchID, neighbor, False, self.topology.ttl_limit))
            elif message.origin == self.parent_switch:
                # 保持与父交换机的连接，即使没有更新
                if message.origin not in self.active_links:
                    self.active_links.append(message.origin)

    def generate_logstring(self):
        log_entries = [f"{self.switchID} - {link}" for link in sorted(self.active_links)]
        return ", ".join(log_entries)



class Topology(object):

    def __init__(self, conf_file: str):
        """This creates all the switches in the Topology from the configuration
        file passed into __init__(). May throw an exception if there is a
        problem with the config file.
        """
        self.switches = {}
        self.messages = []
        self.dropped_switches = []
        self.ttl_limit = 5 # default
        self.drops = [] # default
        self.drop_complete = False
        self.conf_topo = {}
        self.import_conf(conf_file)

    def import_conf(self, conf_file: str):
        try:
            conf = __import__(conf_file)
            if hasattr(conf, "ttl_limit"):
                self.ttl_limit = conf.ttl_limit
            if hasattr(conf, "drops"):
                self.drops = conf.drops
                self.conf_topo = conf.topo
            for key in list(conf.topo.keys()):
                self.switches[key] = Switch(key, self, conf.topo[key])
            # Verify the topology read from file was correct.
            for key in list(self.switches.keys()):
                self.switches[key].verify_neighbors()
        except Exception:
            print(f"Error importing conf_file: {conf_file}")
            raise

    def send_message(self, message: Message):
        if not message.verify_message():
            print("Message is not properly formatted")
            return
        if message.destination in self.switches[message.origin].links:
            self.messages.append(message)
        elif message.origin in self.dropped_switches or message.destination in self.dropped_switches:
            pass
        else:
            print("Messages can only be sent to immediate neighbors")

    def restart_topology_messages(self):
        self.messages = []
        for switch in self.switches:
            self.switches[switch].send_initial_messages()

    def run_spanning_tree(self):
        """This function drives the simulation of a Spanning Tree. It first sends the initial
        messages from each node by invoking send_intial_message. Afterward, each message
        is delivered to the destination switch, where process_message is invoked.
        """
        self.restart_topology_messages()

        while len(self.messages) > 0:
            msg = self.messages.pop(0)
            self.switches[msg.destination].process_message(msg)
            if msg.ttl == 0 and not self.drop_complete:
                for switchId in self.drops:
                    self.drop_switch(switchId)
                self.drop_complete = True

    def drop_switch(self, switchId):
        if switchId not in self.dropped_switches:
            for key in self.switches:
                if switchId in self.conf_topo[key]:
                    self.conf_topo[key].remove(switchId)
                self.switches[key] = Switch(key, self, self.conf_topo[key])
            del self.switches[switchId]
            self.dropped_switches.append(switchId)
            self.restart_topology_messages()

    def log_spanning_tree(self, filename: str):
        """This function drives the logging of the text file representing the spanning tree.
        It is invoked at the end of the simulation, and iterates through the switches in
        increasing order of ID and invokes the generate_logstring function.  That string
        is written to the file as provided by the student code.
        """
        with open(filename, 'w') as out:
            for switch in sorted(self.switches.keys()):
                entry = self.switches[switch].generate_logstring()
                if switch not in self.dropped_switches:
                    entry += "\n"
                out.write(entry)
            out.close()




PYTHON_VERSION = 3
PYTHON_RELEASE = 11

# Check python version
if sys.version_info < (PYTHON_VERSION, PYTHON_RELEASE):
    print("Warning:")
    print(f"    Please be sure you are using at least Python {PYTHON_VERSION}.{PYTHON_RELEASE}.x")
    exit()

if len(sys.argv) != 2:
    print("Syntax:")
    print("    python run.py <topology_file>")
    exit()

topology_file = sys.argv[1]
# Check topology_file
if topology_file.endswith('.py'):
    topology_file = topology_file[:-3]
    print("Syntax:")
    print("    Note that the topology parameter should not have the .py extension.")
    print("    Removing the '.py' extension...")

# Populate the topology
topo = Topology(topology_file)

# Run the topology
topo.run_spanning_tree()
# Close the logfile
topo.log_spanning_tree(f"{topology_file}.log")
